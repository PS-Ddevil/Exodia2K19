<!DOCTYPE HTML>
<html>
<body>
<p>Header...</p>
<script>
while(1)
document.body.innerHTML += '1';
</script>
<p>...Footer</p>
</body>
</html>