<?php

$c = mysql_connect("localhost","exodia","Exodia@!2k17") or die("Cannot connect to the database.");
mysql_select_db("exodiict_db",$c) or die("Cannot connect to the database.");

?>