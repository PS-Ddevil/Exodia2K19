// Initialize Firebase
var config = {
apiKey: "AIzaSyCYDk59ufAV3hV6c1F1ffLjMiyE-Ei13IU",
authDomain: "exodia-19.firebaseapp.com",
databaseURL: "https://exodia-19.firebaseio.com",
projectId: "exodia-19",
storageBucket: "exodia-19.appspot.com",
messagingSenderId: "780070740602"
};
firebase.initializeApp(config);
db = firebase.firestore();