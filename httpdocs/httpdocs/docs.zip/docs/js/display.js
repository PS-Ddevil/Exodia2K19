function pad(n) {
    return (n < 10) ? ("0" + n) : n;
}

function print(doc, day, type){
    var x = day + type;
    var div_ = document.getElementById(x);
    var name = doc.data().name;
    var venue = doc.data().venue;
    var start = doc.data().start.toDate().getHours() + ':'+ pad(doc.data().start.toDate().getMinutes());
    var end = doc.data().end.toDate().getHours() + ':'+ pad(doc.data().end.toDate().getMinutes());
    var data = "<tr>" + "<td>" + name + "</td>" + "<td>" + venue + "</td>" + "<td>" + start + "</td>" + "<td>" + end + "</td>" + "</tr>";
    div_.innerHTML += data;
}

db.collection('day1').orderBy("start").onSnapshot(function(querySnapshot){
    x = querySnapshot.docs.length;
    querySnapshot.forEach(function(doc) {
        print(doc, "d1", "_cult");
    });
});

db.collection('day1_t').orderBy("start").onSnapshot(function(querySnapshot){
    x = querySnapshot.docs.length;
    querySnapshot.forEach(function(doc) {
        print(doc, "d1", "_tech");
    });
});

db.collection('day1_w').orderBy("start").onSnapshot(function(querySnapshot){
    x = querySnapshot.docs.length;
    querySnapshot.forEach(function(doc) {
        print(doc, "d1", "_work");
    });
});