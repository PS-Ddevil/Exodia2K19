<?php
$conn = new mysqli("localhost", "exodia_sap", "exodia@12345", "SAP");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//Fetching Values from URL
$name2=$_POST['name1'];
$email2=$_POST['email1'];
$college2=$_POST['college1'];
$phone2=$_POST['phone1'];
$whatsapp2=$_POST['whatsapp1'];
$birthday2=$_POST['birthday1'];
$gender2=$_POST['gender1'];
$sql = "insert into sap_details(name, email, college, phone, whatsapp, birthday, gender) values ('$name2', '$email2', '$college2','$phone2','$whatsapp2','$birthday2','$gender2')";
if ($conn->query($sql) === TRUE) {
    echo "Details recorded successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close(); // Connection Closed
?>